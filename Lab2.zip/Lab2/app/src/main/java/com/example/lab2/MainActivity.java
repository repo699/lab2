package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn;
    Switch sw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConstraintLayout layout=findViewById(R.id.constraintLayout);
        btn=findViewById(R.id.button);
       btn.setEnabled(false);
        sw=findViewById(R.id.switch1);
        CalendarView cal=new CalendarView(getApplicationContext());
        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw.isChecked()){
                    Toast.makeText(getApplicationContext(),"Button Turned On",Toast.LENGTH_SHORT).show();
                    layout.addView(cal);
                   btn.setEnabled(true);

                }else{
                    Toast.makeText(getApplicationContext(),"Button Turned Off",Toast.LENGTH_SHORT).show();
                    layout.removeView(cal);
                    btn.setEnabled((false));
                }
            }
        });



    }
}